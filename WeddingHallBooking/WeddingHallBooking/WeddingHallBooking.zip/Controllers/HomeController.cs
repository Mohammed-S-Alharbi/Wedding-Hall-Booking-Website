using Microsoft.AspNetCore.Mvc;

namespace WeddingHallBooking.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
        public IActionResult About() => View();
        public IActionResult Booking() => View();
        public IActionResult Contact() => View();
        public IActionResult Register() => View();
        public IActionResult Login() => View();
        public IActionResult Mybookings() => View();
    }
}
